## First follow these instructions carefully and only contact me if its not working. 

1. install vs code if you dont have in your system.
refer to these for installation :
https://youtu.be/3eCmc0t6aqA?si=TkV0bVEz_95FbMmi

2. install nodejs if you dont have in your system. 
for installation follow this : 
https://youtu.be/uCgAuOYpJd0?si=2ICwr3Ih1P_ru9KA

3. These two are required to run the code otherwise it'll not work

4. Now open the "valentines" folder which you got in the google drive, in vs code.

5. check again if its the directory of "valentines"

6. Now open the terminal in vs code 

7. type "npm i" or "npm install" in the terminal and press enter


{if you get any error saying script is not installed then :

use this command in the terminal and press enter: 

Set-ExecutionPolicy -Scope CurrentUser Unrestricted

}


8. type "npm run dev" in the terminal and press enter

9. now you will get a local host link, you can CTRL + press and click on the link to view the website in your local system.

10. if you want to share with someone then you will have to host it.

11. for hosting you will need github and vercel. 
here is tutorial for github : 
https://youtu.be/ussgXhJ-cp0?si=kgRrnpFpNedqoWHF

12. here is tutorial for vercel:
https://youtu.be/VigFI4TuwzI?si=z_PC8RMgMe8DxNZk